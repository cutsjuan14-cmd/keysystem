# 🚀 Guía de Despliegue en Railway (paso a paso)

---

## 📁 Archivos que necesitas subir

```
keysystem-railway/
├── server.py
├── keyclient.py
├── requirements.txt
├── Procfile
├── railway.json
└── templates/
    ├── login.html
    └── dashboard.html
```

---

## PASO 1 — Crear cuenta en Railway

1. Ve a → https://railway.app
2. Clic en **"Start a New Project"**
3. Regístrate con tu cuenta de **GitHub** (necesitas tener GitHub)

---

## PASO 2 — Subir el código a GitHub

1. Ve a → https://github.com/new
2. Crea un repositorio privado llamado `keysystem`
3. Descarga **GitHub Desktop** → https://desktop.github.com
4. Clona el repo que creaste
5. Copia todos los archivos de `keysystem-railway/` dentro de la carpeta del repo
6. En GitHub Desktop: escribe un mensaje ("primer commit") y haz **Commit** y luego **Push**

---

## PASO 3 — Crear proyecto en Railway

1. En Railway → clic **"New Project"**
2. Selecciona **"Deploy from GitHub repo"**
3. Elige tu repositorio `keysystem`
4. Railway detectará automáticamente que es Python ✅

---

## PASO 4 — Agregar base de datos PostgreSQL

1. Dentro de tu proyecto Railway → clic **"+ New"**
2. Selecciona **"Database" → "PostgreSQL"**
3. Railway crea la base de datos y conecta automáticamente ✅
4. La variable `DATABASE_URL` se configura sola

---

## PASO 5 — Configurar variables de entorno

En Railway → tu servicio → pestaña **"Variables"** → agrega:

| Variable      | Valor               |
|---------------|---------------------|
| SECRET_KEY    | cualquier texto largo aleatorio (ej: `abc123xyz987...`) |
| ADMIN_USER    | el usuario que quieras (ej: `miusuario`) |
| ADMIN_PASS    | contraseña segura (ej: `MiPass2024!`) |

---

## PASO 6 — Inicializar la base de datos

Railway no ejecuta `init_db()` automáticamente la primera vez.
Tienes dos opciones:

### Opción A (más fácil) — Agregar esta variable:
En Variables agrega:
```
INIT_DB=true
```

### Opción B — Desde la terminal de Railway:
En tu servicio → pestaña **"Shell"** → ejecuta:
```bash
python -c "from server import init_db; init_db()"
```

---

## PASO 7 — Obtener tu URL pública

1. En Railway → tu servicio → pestaña **"Settings"**
2. Busca **"Domains"** → clic **"Generate Domain"**
3. Te dará una URL tipo: `https://keysystem-production-xxxx.up.railway.app`

---

## PASO 8 — Actualizar keyclient.py

Abre `keyclient.py` y cambia esta línea:
```python
SERVER_URL = "https://TU-PROYECTO.up.railway.app"
```
Por tu URL real, ejemplo:
```python
SERVER_URL = "https://keysystem-production-xxxx.up.railway.app"
```

Luego distribuye este `keyclient.py` con tu software.

---

## ✅ Resultado final

- Panel admin: `https://tu-url.up.railway.app` (usuario/contraseña que pusiste)
- API pública: `https://tu-url.up.railway.app/api/validate`
- Cualquier usuario del mundo puede validar su key desde tu software

---

## 💰 Costos Railway

- Plan **Hobby gratuito**: $5 de crédito al mes (suficiente para uso moderado)
- PostgreSQL incluido gratis en el plan
- Si tienes muchos usuarios, el plan Starter es $5/mes

---

## ❓ Problema común

**Error "TemplateNotFound"** → Asegúrate de que la carpeta `templates/` está dentro del repo junto a `server.py`

**Error de conexión DB** → Verifica que agregaste la base de datos PostgreSQL en Railway (Paso 4)
