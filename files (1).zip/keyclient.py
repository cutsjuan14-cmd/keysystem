# -*- coding: utf-8 -*-
"""
keyclient.py — Módulo de validación de keys
Integra este archivo en tu software Python.

Uso básico:
    from keyclient import require_valid_key
    require_valid_key()   # Si la key no es válida, el programa se cierra
"""

import hashlib
import platform
import uuid
import sys
import json
import requests
from pathlib import Path

# ─────────────────────────────
# ⚙️  CONFIGURACIÓN
# ─────────────────────────────
SERVER_URL = "https://TU-PROYECTO.up.railway.app"  # ← Cambia esto con tu URL de Railway
CACHE_FILE = Path.home() / ".myapp_keycache"
TIMEOUT    = 10

# ─────────────────────────────
# HWID
# ─────────────────────────────

def get_hwid() -> str:
    raw = f"{platform.node()}-{platform.machine()}-{uuid.getnode()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]

# ─────────────────────────────
# CACHÉ LOCAL
# ─────────────────────────────

def _save_cache(key: str):
    try:
        CACHE_FILE.write_text(json.dumps({"key": key}), encoding="utf-8")
    except Exception:
        pass

def _load_cache() -> str | None:
    try:
        if CACHE_FILE.exists():
            return json.loads(CACHE_FILE.read_text(encoding="utf-8")).get("key")
    except Exception:
        pass
    return None

def _clear_cache():
    try:
        CACHE_FILE.unlink(missing_ok=True)
    except Exception:
        pass

# ─────────────────────────────
# VALIDACIÓN
# ─────────────────────────────

def validate_key(key: str | None = None) -> dict:
    if not key:
        key = _load_cache()
        if not key:
            return {"valid": False, "error": "No hay key guardada."}

    key  = key.strip().upper()
    hwid = get_hwid()

    try:
        r = requests.post(
            f"{SERVER_URL}/api/validate",
            json={"key": key, "hwid": hwid},
            timeout=TIMEOUT
        )
        result = r.json()
        if result.get("valid"):
            _save_cache(key)
        return result
    except requests.exceptions.ConnectionError:
        return {"valid": False, "error": f"No se puede conectar al servidor."}
    except requests.exceptions.Timeout:
        return {"valid": False, "error": "Timeout al conectar."}
    except Exception as e:
        return {"valid": False, "error": str(e)}


def require_valid_key(exit_on_fail: bool = True) -> dict:
    """
    Coloca esto al inicio de tu script.
    Pide la key si no está guardada, valida y sale si no es válida.
    """
    key = _load_cache()
    if not key:
        print("\n" + "─"*50)
        print("  🔑 ACTIVACIÓN REQUERIDA")
        print("─"*50)
        key = input("  Introduce tu key de acceso: ").strip()

    result = validate_key(key)

    if result.get("valid"):
        dias = result.get("days_remaining", "?")
        print(f"\n  ✅ Acceso concedido — {dias} días restantes\n")
        return result
    else:
        print(f"\n  ❌ {result.get('error', 'Key inválida')}\n")
        _clear_cache()
        if exit_on_fail:
            sys.exit(1)
        return result


# Test rápido
if __name__ == "__main__":
    print(f"HWID: {get_hwid()}")
    key_arg = input("Key a probar: ").strip()
    print(validate_key(key_arg))
